package com.example.studentmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.INotificationSideChannel;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity {
    private StudentSQL dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //我希望完成的功能：  登陆界面, 记录身高体重和体温并计算BMI 提示健康建议
        //学生可以添加课程表 并且会添加闹钟来 提前10分钟提醒学生上课

        ImageView imageView = (ImageView) findViewById(R.id.tubiao);
        //这里添加图标并给图标添加旋转动画  在ima_animation中设置旋转
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.img_animation);
        LinearInterpolator lin = new LinearInterpolator();//设置动画匀速运动
        animation.setInterpolator(lin);
        imageView.startAnimation(animation);
        //到这里图标旋转功能完成
        dbHelper = new StudentSQL(this,"Student.db",null,1);
        final SQLiteDatabase db = dbHelper.getWritableDatabase();
        //接下来是注册部分  需要弹出一个对话框输入
        ImageButton zhuce = findViewById(R.id.zhuce);
        //对话框需要fragment以及alertdialog
        zhuce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int[] m = {1};
                final View view =  LayoutInflater.from(MainActivity.this).inflate(R.layout.fragment_zhuce,null);
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("注册");
                dialog.setView(view);      //将注册界面放入对话框中
                //接下来设置取消和确定
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                   //取消则不需要任何的操作  只需要关闭对话框
                    }
                });
                //确定的话则需要先判断两次密码是否一样  是否有没有输入的信息
                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        EditText xingming = view.findViewById(R.id.xingming);
                        EditText mima = view.findViewById(R.id.mima);
                        EditText mima2 = view.findViewById(R.id.mima2);
                        EditText xuehaot = view.findViewById(R.id.xuehao);
                        //先判断是否有空的输入
                        if(xingming.getText().toString().isEmpty()||mima.getText().toString().isEmpty()||mima2.getText().toString().isEmpty()||xuehaot.getText().toString().isEmpty()){
                            Toast.makeText(MainActivity.this,"请输入全部信息",Toast.LENGTH_SHORT).show();
                            m[0] =0;   //为0不可用
                        }
                        //接下来判断两次密码是否相同
                        else if(!mima.getText().toString().equals(mima2.getText().toString())){
                            Toast.makeText(MainActivity.this,"两次输入的密码不同",Toast.LENGTH_SHORT).show();
                            m[0]=0;    //为0不可用
                        }
                        //输入都没有问题以后 开始查询数据库中是否有相同学号的人
                        Cursor cursor = db.query("Student",null,null,null,null,null,null);
                        if(cursor.moveToFirst()){
                            do{
                                String xuehao = cursor.getString(cursor.getColumnIndex("xuehao"));
                                if(xuehao.equals(xuehaot.getText().toString())){
                                    Toast.makeText(MainActivity.this,"该学号已注册",Toast.LENGTH_SHORT).show();
                                    m[0]=0;     //为0不可用
                                    break;
                                }
                            }while (cursor.moveToNext());   //如果没找到一样的学号  就查询下一个  如果有就进行Toast提示  并退出遍历
                        }
                        cursor.close();       //到此为止是判断是否已经存在相同学号的人
                        //接下来 如果上述结果都没有问题的话则将数据添加进数据库   这里利用int m来判断是否数据可用  m=1时可用
                        if(m[0]==1){
                            //开始写入数据
                            ContentValues values = new ContentValues();    //给values赋值
                            values.put("name",xingming.getText().toString());
                            values.put("xuehao",xuehaot.getText().toString());
                            values.put("mima",mima.getText().toString());
                            db.insert("Student",null,values);   //放入values
                            values.clear();    //清空values
                            Toast.makeText(MainActivity.this,"注册成功！",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                dialog.show();
            }
        });   //到这是注册模块结束
        //接下来是登录模块  登录需要查询数据库
        ImageButton denglu = findViewById(R.id.denglu);
        final EditText xuehao = findViewById(R.id.xuehao);
        final EditText mima = findViewById(R.id.mima);
        final int[] n = {0};     //设置一个n来判断是否找到该学号   0为失败   其实没必要设置  这里只是在写代码时用来检查输出结果的
        denglu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = db.query("Student",null,null,null,null,null,null);
                if(cursor.moveToFirst()){
                    do{
                        String xuehao1 = cursor.getString(cursor.getColumnIndex("xuehao"));   //xuehao1为数据库中的学号  xuehao是控件上的值
                        String mima1 = cursor.getString(cursor.getColumnIndex("mima"));   //mima1同理
                        String name1 = cursor.getString(cursor.getColumnIndex("name"));
                        if(xuehao1.equals(xuehao.getText().toString())){
                            if(mima1.equals(mima.getText().toString())){
                                n[0]=1;  //1是找到了该学号  其实也没必要设置
                                //登陆成功  跳转到学生个人界面
                                ////////////////////////////////////////////////////////////////////////////////
                                Intent intent = new Intent(MainActivity.this,SecondActivity.class);
                                intent.putExtra("xuehao",xuehao1);       //登录成功的话  跳转到SecondActivity  并且将该学生的学号传过去
                                intent.putExtra("name",name1);
                                intent.putExtra("mima",mima1);
                                startActivity(intent);     //跳转到SecondActivity

                                break;
                            }
                            else{
                                Toast.makeText(MainActivity.this,"密码错误",Toast.LENGTH_SHORT).show();
                                n[0]=1;
                                break;
                            }
                        }
                    }while (cursor.moveToNext());   //如果没找到一样的学号  就查询下一个  如果有就进行Toast提示  并退出遍历
                    if(n[0]==0) {
                        Toast.makeText(MainActivity.this, "该学号未进行注册", Toast.LENGTH_SHORT).show();
                    }
                }
                cursor.close();       //到此为止是判断是否登陆成功






            }
        });



















    }
}