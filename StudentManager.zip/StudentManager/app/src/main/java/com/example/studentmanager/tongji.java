package com.example.studentmanager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class tongji extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tongji);
        setContentView(new CustomView(tongji.this));




    }




    //内部类中编写
    class CustomView extends View {

        //定义各个坐标的位置变量

        public CustomView(Context context) {
            super(context);
        }
        //画的方法
        @Override
        protected void onDraw(Canvas canvas) {
            Paint black = new Paint();
            black.setColor(Color.BLACK);
            black.setStrokeWidth(10);
            black.setTextSize(50);
            canvas.drawLine(50,50,50,1050,black);
            canvas.drawLine(50,1050,1050,1050,black);
            //创建画笔对象
            Paint tizhongP = new Paint();   //体重
            //为不同的属性设置不同的画笔的颜色
            tizhongP.setColor(Color.BLUE);
            tizhongP.setStrokeWidth(10);
            tizhongP.setTextSize(50);

            Paint shengaoP = new Paint();   //身高
            //为不同的属性设置不同的画笔的颜色
            shengaoP.setColor(Color.GREEN);
            shengaoP.setStrokeWidth(10);
            shengaoP.setTextSize(50);

            Paint tiwenP = new Paint();   //体温
            //为不同的属性设置不同的画笔的颜色
            tiwenP.setColor(Color.RED);
            tiwenP.setStrokeWidth(10);
            tiwenP.setTextSize(50);


            ArrayList DATA = getIntent().getStringArrayListExtra("DATA");
            if (DATA.size() > 1) {
                float shengao1 = Float.parseFloat(DATA.get(0).toString().substring(DATA.get(0).toString().indexOf("身高")+3,DATA.get(0).toString().indexOf("C")));   //  将身高分解出来

                float tizhong1 = Float.parseFloat(DATA.get(0).toString().substring(DATA.get(0).toString().indexOf("体重")+3,DATA.get(0).toString().indexOf("K")));    //  将体重分解出来

                float tiwen1 = Float.parseFloat(DATA.get(0).toString().substring(DATA.get(0).toString().indexOf("体温")+3,DATA.get(0).toString().indexOf("℃")));     //  将体温分解出来

                //画直线的方法，把各个点的坐标值传进去
                float shengaoX1=50;
                float shengaoY1=1650-(shengao1-120)*20;
                float tizhongX1=50;
                float tizhongY1=1050-(tizhong1-30)*10;
                float tiwenX1=50;
                float tiwenY1=1050-(tiwen1-34)*100;
                canvas.drawText(shengao1+"cm",50,shengaoY1,shengaoP);
                canvas.drawText(tizhong1+"kg",50,tizhongY1,tizhongP);
                canvas.drawText(tiwen1+"℃",50,tiwenY1,tiwenP);



                for (int i = 1; i < DATA.size(); i++) {  //先将身高体重体温进行分解
                    float shengao2 = Float.parseFloat(DATA.get(i).toString().substring(DATA.get(i).toString().indexOf("身高")+3,DATA.get(i).toString().indexOf("C")));   //  将身高分解出来

                    float tizhong2 = Float.parseFloat(DATA.get(i).toString().substring(DATA.get(i).toString().indexOf("体重")+3,DATA.get(i).toString().indexOf("K")));    //  将体重分解出来

                    float tiwen2 = Float.parseFloat(DATA.get(i).toString().substring(DATA.get(i).toString().indexOf("体温")+3,DATA.get(i).toString().indexOf("℃")));     //  将体温分解出来


                    float jiange = 900/(DATA.size()-1);     //将距离1000除以数据的量，这样可以让多个数据平均出现的图中

                    float shengaoX2=shengaoX1+jiange;
                    float shengaoY2=1650-(shengao2-120)*20;
                    float tizhongX2=tizhongX1 +jiange;
                    float tizhongY2=1050-(tizhong2-30)*10;
                    float tiwenX2=tiwenX1+jiange;
                    float tiwenY2=1050-(tiwen2-34)*100;
                    //接下来绘制身高折线图
                    canvas.drawLine(shengaoX1, shengaoY1, shengaoX2,shengaoY2,shengaoP);
                    canvas.drawText(shengao2+"cm",shengaoX2,shengaoY2,shengaoP);
                    //体重
                    canvas.drawLine(tizhongX1,tizhongY1,tizhongX2,tizhongY2,tizhongP);
                    canvas.drawText(tizhong2+"kg",tizhongX2,tizhongY2,tizhongP);
                    //体温
                    canvas.drawLine(tiwenX1,tiwenY1,tiwenX2,tiwenY2,tiwenP);
                    canvas.drawText(tiwen2+"℃",tiwenX2,tiwenY2,tiwenP);

                    shengaoX1 = shengaoX2;
                    shengaoY1 = shengaoY2;
                    tizhongX1 = tizhongX2;
                    tizhongY1 = tizhongY2;
                    tiwenX1 = tiwenX2;
                    tiwenY1 = tiwenY2;

                    super.onDraw(canvas);
                }

                Paint tizhongP2 = new Paint();   //体重
                //为不同的属性设置不同的画笔的颜色
                tizhongP2.setColor(Color.BLUE);
                tizhongP2.setStrokeWidth(10);
                tizhongP2.setTextSize(100);

                Paint shengaoP2 = new Paint();   //身高
                //为不同的属性设置不同的画笔的颜色
                shengaoP2.setColor(Color.GREEN);
                shengaoP2.setStrokeWidth(10);
                shengaoP2.setTextSize(100);

                Paint tiwenP2 = new Paint();   //体温
                //为不同的属性设置不同的画笔的颜色
                tiwenP2.setColor(Color.RED);
                tiwenP2.setStrokeWidth(10);
                tiwenP2.setTextSize(100);



                canvas.drawText("体重:—",100,1200,tizhongP2);
                canvas.drawText("身高:—",100,1300,shengaoP2);
                canvas.drawText("体温:—",100,1400,tiwenP2);
                canvas.drawText(getIntent().getStringExtra("name").toString()+"同学的健康折线统计图",400,1200,black);
                invalidate();
            }
            }
        }



}