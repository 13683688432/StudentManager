package com.example.studentmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SecondActivity extends AppCompatActivity {
    private StudentSQL dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        TextView huanying = findViewById(R.id.huanying);
        huanying.setText("欢迎！ "+getIntent().getStringExtra("name")+"同学");
        ImageButton tuichu = findViewById(R.id.tuichu);
        tuichu.setOnClickListener(new View.OnClickListener() {   //按下退出按钮  直接返回登陆界面
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SecondActivity.this,MainActivity.class));   //跳转回MainActivity
            }
        });
        TextView zhuangtai1 = findViewById(R.id.zhuangtai1);
        ImageButton jilu = findViewById(R.id.jilu);
        jilu.setOnClickListener(new View.OnClickListener() {   //点击记录  实现对话框输入  以及添加进数据库
            @Override
            public void onClick(View v) {
                final int []m = {1};  //m[0]为1代表数据可接受
                final View view =  LayoutInflater.from(SecondActivity.this).inflate(R.layout.fragment_jilu,null);
                AlertDialog.Builder dialog = new AlertDialog.Builder(SecondActivity.this);
                dialog.setTitle("日常记录");
                dialog.setView(view);      //将注册界面放入对话框中
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //取消则不需要任何的操作  只需要关闭对话框
                    }
                });
                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        EditText shengaoT =view.findViewById(R.id.shengaoT);
                        EditText tizhongT =view.findViewById(R.id.tizhongT);
                        EditText tiwenT =view.findViewById(R.id.tiwenT);
                        if(shengaoT.getText().toString().isEmpty()||tizhongT.getText().toString().isEmpty()||tiwenT.getText().toString().isEmpty()){
                            //如果有空的  则Toast提示
                            Toast.makeText(SecondActivity.this,"请输入全部信息",Toast.LENGTH_SHORT).show();
                            m[0]=0;  //为0不可接受
                        }
                        else if(Double.parseDouble(shengaoT.getText().toString())<120||Double.parseDouble(shengaoT.getText().toString())>220){
                            //判断是否身高输入数值过大或者过小
                            Toast.makeText(SecondActivity.this,"身高输入超出范围",Toast.LENGTH_SHORT).show();
                            m[0]=0;  //为0不可接受
                        }
                        else if(Double.parseDouble(tizhongT.getText().toString())<30||Double.parseDouble(tizhongT.getText().toString())>250){
                            //判断是否体重输入数值过大或者过小
                            Toast.makeText(SecondActivity.this,"体重输入超出范围",Toast.LENGTH_SHORT).show();
                            m[0]=0;  //为0不可接受
                        }
                        else if(Double.parseDouble(tiwenT.getText().toString())<34||Double.parseDouble(tiwenT.getText().toString())>45){
                            //判断是否体重输入数值过大或者过小
                            Toast.makeText(SecondActivity.this,"体温输入超出范围",Toast.LENGTH_SHORT).show();
                            m[0]=0;  //为0不可接受
                        }
                        //这里时判断结果没有问题
                    if(m[0]==1){
                        dbHelper = new StudentSQL(SecondActivity.this,"Student.db",null,1);
                        final SQLiteDatabase db = dbHelper.getWritableDatabase();
                        //开始写入数据
                        ContentValues values = new ContentValues();    //给values赋值
                        String xingming = getIntent().getStringExtra("name");
                        String xuehao = getIntent().getStringExtra("xuehao");
                        String mima = getIntent().getStringExtra("mima");

                        values.put("name",xingming);   //姓名
                        values.put("xuehao",xuehao);   //学号
                        values.put("mima",mima);    //密码
                        values.put("shengao",Double.parseDouble(shengaoT.getText().toString()));    //身高
                        values.put("tizhong",Double.parseDouble(tizhongT.getText().toString()));    //体重
                        values.put("tiwen",Double.parseDouble(tiwenT.getText().toString()));        //体温
                        DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        Date date = new Date(System.currentTimeMillis());       //获取当前时间
                        String currentDate = simpleDateFormat.format(date);
                        values.put("time",currentDate);    //放入时间




                        db.insert("Student",null,values);   //放入values
                        values.clear();    //清空values
                        //这里是体型BMI模块
                        TextView zhuangtai1 = findViewById(R.id.zhuangtai1);
                        double shengaopingfang =Double.parseDouble(shengaoT.getText().toString())*Double.parseDouble(shengaoT.getText().toString());

                        //这里先乘100再除以100时为了将小数点后两位四舍五入
                        double BMI = (Double.parseDouble(tizhongT.getText().toString())*10000)/shengaopingfang;   //体重除以身高的平方
                        BMI = Math.round(BMI*100);
                        BMI = BMI/100;
                        //这里先乘100再除以100时为了将小数点后两位四舍五入
                        if(BMI<18.5){
                            zhuangtai1.setText("今日BMI： "+BMI+"\n"+"体型偏瘦了，要好好吃饭!");
                        }
                        else if(BMI>18.49&&BMI<23.91){
                            zhuangtai1.setText("今日BMI： "+BMI+"\n"+"体型正常，继续保持！");
                        }
                        else if(BMI>23.9&&BMI<27.91){
                            zhuangtai1.setText("今日BMI： "+BMI+"\n"+"体型超重，要注意饮食！");
                        }
                        else if(BMI>27.9){
                            zhuangtai1.setText("今日BMI： "+BMI+"\n"+"肥胖体型！");
                        }
                        //接下来是体温模块
                        TextView zhuangtai2 = findViewById(R.id.zhuangtai2);
                        if(Double.parseDouble(tiwenT.getText().toString())<36){
                            zhuangtai2.setText("体温: "+Double.parseDouble(tiwenT.getText().toString())+"℃"+"\n"+"体温过低，请注意取暖");
                        }
                        if(Double.parseDouble(tiwenT.getText().toString())>35.9&&Double.parseDouble(tiwenT.getText().toString())<37.5){
                            zhuangtai2.setText("体温: "+Double.parseDouble(tiwenT.getText().toString())+"℃"+"\n"+"体温正常！请继续保持");
                        }
                        if(Double.parseDouble(tiwenT.getText().toString())>37.4&&Double.parseDouble(tiwenT.getText().toString())<38.1){
                            zhuangtai2.setText("体温: "+Double.parseDouble(tiwenT.getText().toString())+"℃"+"\n"+"低热，若无其他不适，可服用常规退烧药");
                        }
                        if(Double.parseDouble(tiwenT.getText().toString())>38&&Double.parseDouble(tiwenT.getText().toString())<42){
                            zhuangtai2.setText("体温: "+Double.parseDouble(tiwenT.getText().toString())+"℃"+"\n"+"高烧！请及时就医");
                        }
                    }
                    }
                });
                dialog.show();
            }
        });        //这里是记录身体状态模块结束
        //接下来是查看身体状态的历史记录
        ImageButton chakan = findViewById(R.id.chakan);
        chakan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String [] data= new String[100];                    //new String[31];     //这里用来存放历史记录   可以存放31次的
                int i=0;
                int j=0;    //j用于记录data数组有数据部分的位置
                dbHelper = new StudentSQL(SecondActivity.this,"Student.db",null,1);
                final SQLiteDatabase db = dbHelper.getWritableDatabase();
                final Cursor cursor = db.query("Student",null,null,null,null,null,null);
                if(cursor.moveToFirst()){       //进入遍历  查找当前学号的所有内容
                    do{
                        String xuehao = cursor.getString(cursor.getColumnIndex("xuehao"));
                        String intentxuehao = getIntent().getStringExtra("xuehao");
                        Double shengao = cursor.getDouble(cursor.getColumnIndex("shengao"));
                        Double tizhong = cursor.getDouble(cursor.getColumnIndex("tizhong"));
                        Double tiwen = cursor.getDouble(cursor.getColumnIndex("tiwen"));
                        String time = cursor.getString(cursor.getColumnIndex("time"));
                        if(xuehao.equals(intentxuehao)){
                            //如果在数据库中找到该学号的内容  就记录下来
                             //这里向data中存放历史数据


                        //这里判断身高不为0是因此 后续添加课程时会出现身高体重体温都为0的数据  而这些数据不应添加进健康系统的列表里
                            if(i!=0) {      //第一次出现的数据一定是初始化时的数据  初始化时的数据是没有身高体重体温的  所以要忽略掉
                                data[i-1] = "身高：" + shengao + " CM    " + "体重：" + tizhong + " KG\n" + "体温：" + tiwen + " ℃   "+"记录时间：" + time;
                                j++;   //J加1  代表有数据部分加1
                            }
                            i++;    //i用于动态添加字符串数组元素
                        }
                    }while (cursor.moveToNext());
                    cursor.close();
                }

                //遍历完成  开始输出  跳出对话框
                View view =  LayoutInflater.from(SecondActivity.this).inflate(R.layout.fragment_lishijilu,null);
                AlertDialog.Builder dialog = new AlertDialog.Builder(SecondActivity.this);

                dialog.setTitle("历史记录");
                dialog.setView(view);      //将历史记录界面放入对话框中
                                //输出的时候这里出现了闪退  分析结果是  data[]中空的部分会导致闪退  因此需要将data中有数据的部分放入另一个String数组中
                String []DATA = new String[j];   //  和data的数据长度一致   j其实是data的有数据位置+1  但+1后正好就是长度
                for(int k=0;k<j;k++){  //利用循环将data中的数据放入DATA
                    DATA[k] = data[k];
                }

                ArrayAdapter<String>adapter = new ArrayAdapter<String>(SecondActivity.this,android.R.layout.simple_list_item_1,DATA);
                ListView jiluLS = view.findViewById(R.id.jiluLS);
                jiluLS.setAdapter(adapter);         //这里出现了一个问题 就是ListView划到最底部会闪退   已经解决：因为没有数据  适配器得不到数据  因此出现异常
                /////////////////////////////////////////////////////////
                dialog.setPositiveButton("清空记录", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int i=0;   //为0的话代表这个数据是初始化的数据  不用清空
                        final Cursor cursor = db.query("Student",null,null,null,null,null,null);
                        if(cursor.moveToFirst()){       //进入遍历  查找当前学号的所有内容
                            do{
                                String xuehao = cursor.getString(cursor.getColumnIndex("xuehao"));
                                String intentxuehao = getIntent().getStringExtra("xuehao");
                                if(xuehao.equals(intentxuehao)){
                                    if(i==0){
                                        i=1;
                                    }
                                    else if(i==1){   //经过第一个初始化的数据后  后面都是为1  需要清空
                                        db.delete("Student","id =?", new String[]{cursor.getInt(cursor.getColumnIndex("id")) + ""});
                                    }
                                }
                            }while (cursor.moveToNext());
                            cursor.close();
                        }
                    }
                }).setNegativeButton("返回", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //返回则没有任何动作
                    }
                });
               dialog.show();
               //这里出现了问题   就是setView的前后  在这里我是在的fragment中使用listview  因此应当先setView  之后再进行listview的配置
            }
        });
        //到这里是查看模块的结束

        ////////////这里是整个健康管理系统的结束
        //接下来建立新的数据库用以村







    }
}