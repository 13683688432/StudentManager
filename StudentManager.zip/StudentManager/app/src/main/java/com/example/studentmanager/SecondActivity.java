package com.example.studentmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.zip.Inflater;

public class SecondActivity extends AppCompatActivity {
    private StudentSQL dbHelper;
    private MediaPlayer mediaPlayer = new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        TextView huanying = findViewById(R.id.huanying);
        shuaxin();     //这里被我单独拿出来写成了个方法  即能作为初始化  也能作为刷新使用





        huanying.setText("欢迎！"+getIntent().getStringExtra("name")+"同学");
        ImageButton tuichu = findViewById(R.id.tuichu);
        tuichu.setOnClickListener(new View.OnClickListener() {   //按下退出按钮  直接返回登陆界面
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SecondActivity.this,MainActivity.class));   //跳转回MainActivity
            }
        });
        TextView zhuangtai1 = findViewById(R.id.zhuangtai1);
        ImageButton jilu = findViewById(R.id.jilu);
        jilu.setOnClickListener(new View.OnClickListener() {   //点击记录  实现对话框输入  以及添加进数据库
            @Override
            public void onClick(View v) {
                final int []m = {1};  //m[0]为1代表数据可接受
                final View view =  LayoutInflater.from(SecondActivity.this).inflate(R.layout.fragment_jilu,null);
                AlertDialog.Builder dialog = new AlertDialog.Builder(SecondActivity.this);
                dialog.setTitle("日常记录");
                dialog.setView(view);      //将注册界面放入对话框中
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //取消则不需要任何的操作  只需要关闭对话框
                    }
                });
                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        EditText shengaoT =view.findViewById(R.id.shengaoT);
                        EditText tizhongT =view.findViewById(R.id.tizhongT);
                        EditText tiwenT =view.findViewById(R.id.tiwenT);
                        if(shengaoT.getText().toString().isEmpty()||tizhongT.getText().toString().isEmpty()||tiwenT.getText().toString().isEmpty()){
                            //如果有空的  则Toast提示
                            Toast.makeText(SecondActivity.this,"请输入全部信息",Toast.LENGTH_SHORT).show();
                            m[0]=0;  //为0不可接受
                        }
                        else if(Double.parseDouble(shengaoT.getText().toString())<120||Double.parseDouble(shengaoT.getText().toString())>220){
                            //判断是否身高输入数值过大或者过小
                            Toast.makeText(SecondActivity.this,"身高输入超出范围",Toast.LENGTH_SHORT).show();
                            m[0]=0;  //为0不可接受
                        }
                        else if(Double.parseDouble(tizhongT.getText().toString())<30||Double.parseDouble(tizhongT.getText().toString())>250){
                            //判断是否体重输入数值过大或者过小
                            Toast.makeText(SecondActivity.this,"体重输入超出范围",Toast.LENGTH_SHORT).show();
                            m[0]=0;  //为0不可接受
                        }
                        else if(Double.parseDouble(tiwenT.getText().toString())<34||Double.parseDouble(tiwenT.getText().toString())>45){
                            //判断是否体重输入数值过大或者过小
                            Toast.makeText(SecondActivity.this,"体温输入超出范围",Toast.LENGTH_SHORT).show();
                            m[0]=0;  //为0不可接受
                        }
                        //这里时判断结果没有问题
                        if(m[0]==1){
                            dbHelper = new StudentSQL(SecondActivity.this,"Student.db",null,1);
                            final SQLiteDatabase db = dbHelper.getWritableDatabase();
                            //开始写入数据
                            ContentValues values = new ContentValues();    //给values赋值
                            String xingming = getIntent().getStringExtra("name");
                            String xuehao = getIntent().getStringExtra("xuehao");
                            String mima = getIntent().getStringExtra("mima");

                            values.put("name",xingming);   //姓名
                            values.put("xuehao",xuehao);   //学号
                            values.put("mima",mima);    //密码
                            values.put("shengao",Double.parseDouble(shengaoT.getText().toString()));    //身高
                            values.put("tizhong",Double.parseDouble(tizhongT.getText().toString()));    //体重
                            values.put("tiwen",Double.parseDouble(tiwenT.getText().toString()));        //体温
                            DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            Date date = new Date(System.currentTimeMillis());       //获取当前时间
                            String currentDate = simpleDateFormat.format(date);
                            values.put("time",currentDate);    //放入时间




                            db.insert("Student",null,values);   //放入values
                            values.clear();    //清空values
                            //这里是体型BMI模块
                            TextView zhuangtai1 = findViewById(R.id.zhuangtai1);
                            double shengaopingfang =Double.parseDouble(shengaoT.getText().toString())*Double.parseDouble(shengaoT.getText().toString());

                            //这里先乘100再除以100时为了将小数点后两位四舍五入
                            double BMI = (Double.parseDouble(tizhongT.getText().toString())*10000)/shengaopingfang;   //体重除以身高的平方
                            BMI = Math.round(BMI*100);
                            BMI = BMI/100;
                            //这里先乘100再除以100时为了将小数点后两位四舍五入
                            if(BMI<18.5){
                                zhuangtai1.setText("今日BMI： "+BMI+"\n"+"体型偏瘦了，要好好吃饭!");
                            }
                            else if(BMI>18.49&&BMI<23.91){
                                zhuangtai1.setText("今日BMI： "+BMI+"\n"+"体型正常，继续保持！");
                            }
                            else if(BMI>23.9&&BMI<27.91){
                                zhuangtai1.setText("今日BMI： "+BMI+"\n"+"体型超重，要注意饮食！");
                            }
                            else if(BMI>27.9){
                                zhuangtai1.setText("今日BMI： "+BMI+"\n"+"肥胖体型！");
                            }
                            //接下来是体温模块
                            TextView zhuangtai2 = findViewById(R.id.zhuangtai2);
                            if(Double.parseDouble(tiwenT.getText().toString())<36){
                                zhuangtai2.setText("体温: "+Double.parseDouble(tiwenT.getText().toString())+"℃"+"\n"+"体温过低，请注意取暖");
                            }
                            if(Double.parseDouble(tiwenT.getText().toString())>35.9&&Double.parseDouble(tiwenT.getText().toString())<37.5){
                                zhuangtai2.setText("体温: "+Double.parseDouble(tiwenT.getText().toString())+"℃"+"\n"+"体温正常！请继续保持");
                            }
                            if(Double.parseDouble(tiwenT.getText().toString())>37.4&&Double.parseDouble(tiwenT.getText().toString())<38.1){
                                zhuangtai2.setText("体温: "+Double.parseDouble(tiwenT.getText().toString())+"℃"+"\n"+"低热，若无其他不适，可服用常规退烧药");
                            }
                            if(Double.parseDouble(tiwenT.getText().toString())>38&&Double.parseDouble(tiwenT.getText().toString())<42){
                                zhuangtai2.setText("体温: "+Double.parseDouble(tiwenT.getText().toString())+"℃"+"\n"+"高烧！请及时就医");
                            }
                        }
                    }
                });
                dialog.show();
            }
        });        //这里是记录身体状态模块结束
        //接下来是查看身体状态的历史记录
        ImageButton chakan = findViewById(R.id.chakan);
        chakan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String [] data= new String[100];                    //new String[31];     //这里用来存放历史记录   可以存放31次的
                int i=0;
                int j=0;    //j用于记录data数组有数据部分的位置
                dbHelper = new StudentSQL(SecondActivity.this,"Student.db",null,1);
                final SQLiteDatabase db = dbHelper.getWritableDatabase();
                final Cursor cursor = db.query("Student",null,null,null,null,null,null);
                if(cursor.moveToFirst()){       //进入遍历  查找当前学号的所有内容
                    do{
                        String xuehao = cursor.getString(cursor.getColumnIndex("xuehao"));
                        String intentxuehao = getIntent().getStringExtra("xuehao");
                        Double shengao = cursor.getDouble(cursor.getColumnIndex("shengao"));
                        Double tizhong = cursor.getDouble(cursor.getColumnIndex("tizhong"));
                        Double tiwen = cursor.getDouble(cursor.getColumnIndex("tiwen"));
                        String time = cursor.getString(cursor.getColumnIndex("time"));
                        if(xuehao.equals(intentxuehao)){
                            //如果在数据库中找到该学号的内容  就记录下来
                            //这里向data中存放历史数据


                            //这里判断身高不为0是因此 后续添加课程时会出现身高体重体温都为0的数据  而这些数据不应添加进健康系统的列表里
                            if(i!=0&&shengao!=0) {      //第一次出现的数据一定是初始化时的数据  初始化时的数据是没有身高体重体温的  所以要忽略掉
                                data[i-1] = "身高：" + shengao + " CM    " + "体重：" + tizhong + " KG\n" + "体温：" + tiwen + " ℃   "+"记录时间：" + time;
                                j++;   //J加1  代表有数据部分加1
                            }
                            i++;    //i用于动态添加字符串数组元素
                        }
                    }while (cursor.moveToNext());
                    cursor.close();
                }

                //遍历完成  开始输出  跳出对话框
                View view =  LayoutInflater.from(SecondActivity.this).inflate(R.layout.fragment_lishijilu,null);
                AlertDialog.Builder dialog = new AlertDialog.Builder(SecondActivity.this);

                dialog.setTitle("历史记录");
                dialog.setView(view);      //将历史记录界面放入对话框中
                //输出的时候这里出现了闪退  分析结果是  data[]中空的部分会导致闪退  因此需要将data中有数据的部分放入另一个String数组中
                String []DATA = new String[j];   //  和data的数据长度一致   j其实是data的有数据位置+1  但+1后正好就是长度
                for(int k=0;k<j;k++){  //利用循环将data中的数据放入DATA
                    DATA[k] = data[k];
                }

                ArrayAdapter<String>adapter = new ArrayAdapter<String>(SecondActivity.this,android.R.layout.simple_list_item_1,DATA);
                ListView jiluLS = view.findViewById(R.id.jiluLS);
                jiluLS.setAdapter(adapter);         //这里出现了一个问题 就是ListView划到最底部会闪退   已经解决：因为没有数据  适配器得不到数据  因此出现异常
                /////////////////////////////////////////////////////////
                dialog.setPositiveButton("清空记录", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int i=0;   //为0的话代表这个数据是初始化的数据  不用清空
                        final Cursor cursor = db.query("Student",null,null,null,null,null,null);
                        if(cursor.moveToFirst()){       //进入遍历  查找当前学号的所有内容
                            do{
                                String xuehao = cursor.getString(cursor.getColumnIndex("xuehao"));
                                String intentxuehao = getIntent().getStringExtra("xuehao");
                                Double shengao = cursor.getDouble(cursor.getColumnIndex("shengao"));
                                //这里的身高用于后续判断是否是用于判断健康状态的数据  如果为0的话 则是课程的数据

                                if(xuehao.equals(intentxuehao)){
                                    if(i==0){
                                        i=1;
                                    }
                                    else if(i==1&&shengao!=0){   //经过第一个初始化的数据后  后面都是为1  需要清空  shengao不为0的话说明是健康系统的数据 为0则是课程数据
                                        db.delete("Student","id =?", new String[]{cursor.getInt(cursor.getColumnIndex("id")) + ""});
                                        //这样清空以后会剩下课程的数据
                                    }
                                }
                            }while (cursor.moveToNext());
                            cursor.close();
                        }
                    }
                }).setNegativeButton("返回", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //返回则没有任何动作
                    }
                });
                dialog.show();
                //这里出现了问题   就是setView的前后  在这里我是在的fragment中使用listview  因此应当先setView  之后再进行listview的配置
            }
        });
        //到这里是查看模块的结束

        ////////////这里是整个健康管理系统的结束
        ImageButton tianjiakecheng = findViewById(R.id.tianjiakecheng);
        tianjiakecheng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final View view =  LayoutInflater.from(SecondActivity.this).inflate(R.layout.fragment_tianjiakecheng,null);
                AlertDialog.Builder dialog = new AlertDialog.Builder(SecondActivity.this);
                dialog.setTitle("添加课程");
                dialog.setView(view);      //将添加课程界面放入对话框中
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //取消则不做操作
                    }
                });
                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dbHelper = new StudentSQL(SecondActivity.this,"Student.db",null,1);
                        final SQLiteDatabase db = dbHelper.getWritableDatabase();
                        //确定后先确认是否有空的输入
                        int []m = {1};      //m[0]为1代表数据可用
                        EditText kechengmingcheng = view.findViewById(R.id.kechengmingcheng);
                        EditText coursetime = view.findViewById(R.id.coursetime);
                        RadioGroup zhou = view.findViewById(R.id.zhou);
                        if(!coursetime.getText().toString().isEmpty()&&coursetime.getText().toString().indexOf(':')!=-1) {  //时间中需要找到" :  "
                            int xiaoshi = Integer.parseInt(coursetime.getText().toString().substring(0, coursetime.getText().toString().indexOf(':')));
                            int fenzhong = Integer.parseInt(coursetime.getText().toString().substring(coursetime.getText().toString().indexOf(':') + 1));
                            //这里将时间具体的拆分为小时和分钟
                            if (kechengmingcheng.getText().toString().isEmpty()) {
                                Toast.makeText(SecondActivity.this, "请填入课程名称", Toast.LENGTH_SHORT).show();
                                m[0] = 0;  //数据不可用
                            }else if(zhou.getCheckedRadioButtonId() == -1){
                                Toast.makeText(SecondActivity.this, "请选择周一到周日", Toast.LENGTH_SHORT).show();
                                m[0]=0;
                            }else if(coursetime.getText().toString().length()-coursetime.getText().toString().indexOf(':')!=3){
                                Toast.makeText(SecondActivity.this, "分钟需要补齐0", Toast.LENGTH_SHORT).show();
                                m[0]=0;
                            }
                            else if (xiaoshi > 24 || fenzhong > 59) {
                                Toast.makeText(SecondActivity.this, "时间填写不规范", Toast.LENGTH_SHORT).show();
                                m[0] = 0;   //数据不可用
                            }
                            if (m[0] == 1) {
                                int zhouji=0;
                                String s="";
                                int count= zhou.getChildCount();
                                for(int p=0;p<count;p++){
                                    RadioButton rb = (RadioButton)zhou.getChildAt(p);
                                    if(rb.isChecked()){
                                        s = rb.getText().toString();
                                    }
                                }
                                if(s.equals("周一"))
                                {
                                    zhouji=1;
                                }else if(s.equals("周二"))
                                {
                                    zhouji=2;
                                }else if(s.equals("周三"))
                                {
                                    zhouji=3;
                                }
                                else if(s.equals("周四"))
                                {
                                    zhouji=4;
                                }else if(s.equals("周五"))
                                {
                                    zhouji=5;
                                }
                                else if(s.equals("周六"))
                                {
                                    zhouji=6;
                                }
                                else if(s.equals("周日"))
                                {
                                    zhouji=7;
                                }

                                ContentValues values = new ContentValues();    //给values赋值
                                values.put("coursezhou", zhouji);                                        //周几
                                values.put("xuehao", getIntent().getStringExtra("xuehao"));       //学号
                                values.put("coursetime", coursetime.getText().toString());            //课程时间
                                values.put("coursename", kechengmingcheng.getText().toString());    //课程名称
                                db.insert("Student", null, values);   //放入values
                                values.clear();    //清空values
                                Toast.makeText(SecondActivity.this, "课程添加成功", Toast.LENGTH_SHORT).show();
                                shuaxin();   //课程添加成功后直接利用Intent重启SecondActivity
                            }
                        }else if(coursetime.getText().toString().indexOf(':')==-1){  //这里说明时间没有加 “ ： ”
                            Toast.makeText(SecondActivity.this, "时间填写格式不规范", Toast.LENGTH_SHORT).show();
                        }
                        else{     //此处其实写的思路比较混淆  我只是不想整体改  所以写得思路乱了一些  上面等于是 先判断是否时间为 空白 然后拆分时间 避免了时间为空白还要拆分时间  然后再判断是否三个控件有空白
                            Toast.makeText(SecondActivity.this, "请填写时间", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                dialog.show();
            }
        });
        ImageButton deletecourse = findViewById(R.id.deletecourse);
        deletecourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(SecondActivity.this);
                dialog.setMessage("是否要删除所有课程？");
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //没有操作
                    }
                }).setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dbHelper = new StudentSQL(SecondActivity.this,"Student.db",null,1);
                        final SQLiteDatabase db = dbHelper.getWritableDatabase();
                        int i=0;   //为0的话代表这个数据是初始化的数据  不用清空
                        final Cursor cursor = db.query("Student",null,null,null,null,null,null);
                        if(cursor.moveToFirst()){       //进入遍历  查找当前学号的所有内容
                            do{
                                String xuehao = cursor.getString(cursor.getColumnIndex("xuehao"));
                                String intentxuehao = getIntent().getStringExtra("xuehao");
                                int coursezhou = cursor.getInt(cursor.getColumnIndex("coursezhou"));
                                //这里的课程的星期几用于后续判断是否是用于记录课程的数据  如果为0的话 则是健康的数据

                                if(xuehao.equals(intentxuehao)){
                                    if(i==0){
                                        i=1;     //这里过滤掉初始化数据
                                    }
                                    else if(i==1&&coursezhou!=0){   //经过第一个初始化的数据后  后面都是为1  需要清空  shengao不为0的话说明是健康系统的数据 为0则是课程数据
                                        db.delete("Student","id =?", new String[]{cursor.getInt(cursor.getColumnIndex("id")) + ""});
                                        //这样清空以后会剩下健康信息的数据
                                    }
                                }
                            }while (cursor.moveToNext());
                            Toast.makeText(SecondActivity.this, "删除成功！", Toast.LENGTH_SHORT).show();
                            shuaxin();
                            cursor.close();
                        }
                    }
                }).show();
            }
        });



    }

    private void shuaxin() {
        //接下来是再ListView中显示当天的课程   利用学号和coursezhou来判断是否要输出
        dbHelper = new StudentSQL(SecondActivity.this, "Student.db", null, 1);
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        //下面是得到星期几
        final Calendar instance = Calendar.getInstance();
        instance.setTimeInMillis(System.currentTimeMillis());
        int day = instance.get(Calendar.DAY_OF_WEEK);
        int offDay = day;
        switch (offDay % 7) {
            case 0:
                day = 6;
                break;
            case 1:
                day = 7;
                break;
            case 2:
                day = 1;
                break;
            case 3:
                day = 2;
                break;
            case 4:
                day = 3;
                break;
            case 5:
                day = 4;
                break;
            case 6:
                day = 5;
                break;
        }
        String[] DATA = new String[0];
        Cursor cursor = db.query("Student", null, null, null, null, null, null);
        //现在  day就是手机当天的周几
        if (cursor.moveToFirst()) {       //进入遍历  查找当前学号的所有内容
            String[] data = new String[100];
            int i = 0;
            do {
                if (cursor.getString(cursor.getColumnIndex("xuehao")).equals(getIntent().getStringExtra("xuehao")) && cursor.getColumnIndex("coursezhou") != -1) {
                    //如果找到了和当天周几相同的课程数据且学号同Intent传来的学号相同  就将数据去除放入data
                    if (cursor.getInt(cursor.getColumnIndex("coursezhou")) == day) {
                        data[i] = "课程名称： " + cursor.getString(cursor.getColumnIndex("coursename")) + "\n" + "课程时间： " + cursor.getString(cursor.getColumnIndex("coursetime"));
                        i++;
                    }
                }
            } while (cursor.moveToNext());
            cursor.close();
            DATA = new String[i];   //i比位置多1   正好就是数组长度
            for (int j = 0; j < i; j++) {
                DATA[j] = data[j];
            }
            //这样将数据转移 保证DATA中没有空的位置

//            String []DATA = {day+"","11111","","","","","","","","","","","","","","","","","","","",""};
            i = 0;
        }
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(SecondActivity.this, android.R.layout.simple_list_item_1, DATA);
        ListView kechengLS = findViewById(R.id.kechengLS);
        kechengLS.setAdapter(adapter);
        final String [] D = DATA;
        kechengLS.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String A = D[position];
                String time1 = A.substring(A.indexOf("时间")+4);   //现在是时间的格式
                Log.d("该课程开始时间为   ",time1);
                DateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
                Date date = new Date(System.currentTimeMillis());//获取当前时间
                String time2 = simpleDateFormat.format(date);
                Log.d("当前时间为  ",time2);
                final String coursename = A.substring(5,A.indexOf("时间")-2);
                Log.d("课程名称为：",coursename);
                int oneH,oneM;
                if(time1.charAt(0)=='0'){   //如果第一个数字是0  转型时会异常
                    oneH = Integer.parseInt(time1.charAt(1)+"");
                }
                else {
                    oneH = Integer.parseInt(time1.substring(0, time1.indexOf(':')));//当前时间的小时
                }
                if(time1.charAt(time1.indexOf(':')+1)=='0'){
                    oneM = Integer.parseInt(time1.charAt(time1.charAt(time2.indexOf(':')+2))+"");
                }
                else {
                    oneM = Integer.parseInt(time1.substring(time1.indexOf(':') + 1));          //当前时间的分钟
                }          //课程时间的分钟
                Log.d("课程时间分解后为",oneH+" 和 "+oneM);
                int twoH,twoM;
                if(time2.charAt(0)=='0'){   //如果第一个数字是0  转型时会异常
                    twoH = Integer.parseInt(time2.charAt(1)+"");
                }
                else {
                    twoH = Integer.parseInt(time2.substring(0, time2.indexOf(':')));//当前时间的小时
                }
                if(time2.charAt(time2.indexOf(':')+1)=='0'){
                    twoM = Integer.parseInt(time2.charAt(time2.indexOf(':')+2)+"");
                }
                else {
                    twoM = Integer.parseInt(time2.substring(time2.indexOf(':') + 1));          //当前时间的分钟
                }
                Log.d("当前时间分解后为",twoH+ " 和 " +twoM);
                final int S = (oneH-twoH)*3600+(oneM-twoM)*60;
                Log.d("所剩时间为  （秒）",S+"");
                AlertDialog.Builder dialog = new AlertDialog.Builder(SecondActivity.this);
                dialog.setTitle("距离上课还有：");
                if(S>0) {
                    dialog.setMessage((S / 3600) + " 小时 " + (S % 3600) / 60 + " 分钟 ");
                    dialog.setPositiveButton("设定闹钟", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(ContextCompat.checkSelfPermission(SecondActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
                                ActivityCompat.requestPermissions(SecondActivity.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
                            }
                            else {
                                naozhong(S,coursename);
                            }
                        }
                    });
                }
                else{
                    dialog.setMessage("已经上课啦！");
                    dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //确定返回即可
                        }
                    });
                }

                dialog.show();
            }
        });
        
    }
    private void naozhong(int S, final String coursename){
        try {
            File file = new File(Environment.getExternalStorageDirectory(),"music.mp3");
            mediaPlayer.setDataSource(file.getPath());
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        new Handler().postDelayed(new Runnable() {
          @Override
        public void run() {
        mediaPlayer.start();
        mediaPlayer.setLooping(true);
              AlertDialog.Builder dialog = new AlertDialog.Builder(SecondActivity.this);
              dialog.setMessage(coursename+" 上课啦！\n快去上课！");
              dialog.setPositiveButton("好的！关闭闹钟", new DialogInterface.OnClickListener() {
                  @Override
                  public void onClick(DialogInterface dialog, int which) {
                      mediaPlayer.stop();
                  }
              }).show();



        }
        },1000*S);





        }

}