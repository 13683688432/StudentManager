package com.example.studentmanager;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class StudentSQL extends SQLiteOpenHelper {
        private final static String CREATE_STUDENT = "create table Student ("
                +"id integer primary key autoincrement,"
                +"name text,"
                +"xuehao text,"
                +"mima text,"
                +"shengao double,"
                +"tizhong double,"
                +"tiwen double,"
                +"time text)";         //创建按数据库的SQL语句
        private Context mcontext;


    private final static int DATABASE_VERSION = 1;      //版本

    public StudentSQL(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        mcontext = context;
    }




    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_STUDENT);
        Toast.makeText(mcontext,"数据库创建成功！",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

}
